### All of the following have been coded using mutliple TDD iterations ###

def average(num_1, num_2)
  (num_1.to_f + num_2.to_f) / 2           # Used floats here so that it does "real division"
end

def average_array(array)
  array.sum.to_f / array.length           # same case here
end

def repeat(string, number)
  string * number                         # no biggie here
end

def yell(string)
  string.upcase + "!"                     # or here
end

def alternating_case(string)
  words = string.split(" ")               # split the string into an array of words
  words.map!.with_index { |word, index|   # map in place, with an index counter, each word
    if index % 2 == 0
      word.upcase                         # to either uppercase...
    else 
      word.downcase                       # or lowercase depending on it's position in the array
    end
  }
  words.join(" ")                         # put the words back into a string
end

