import React from 'react';

const App = () => {
  return(
    <main className="app">
      <h1>My Super Awesome To Do List App</h1>
    </main>
  )
}

export default App;