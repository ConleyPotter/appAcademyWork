import React from "react";
import Clock from "./frontend/clock";

const App = () => {
  return (
    <div>
      <Clock />
    </div>
  )
}

export default App;