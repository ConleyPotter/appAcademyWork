def my_reject(array, &prc)
  # Keep track of those that aren't rejected
  new_array = []
  # Go through and check if they pass the block, and add them to the array above if they don't
  array.each { |el| new_array << el if !prc.call(el) }
  new_array
end

def my_one?(array, &prc)
  # Keep track of how many are passing the block
  count = 0
  array.each { |el| count += 1 if prc.call(el) }
  # And only return true if one and only one does
  count == 1
end

def hash_select(hash, &prc) 
  # Keep track of those that are passing
  new_hash = {}
  # Go throuh every key and value, if they pass the test, add them to the above hash
  hash.each { |key, val| new_hash[key] = val if prc.call(key, val) }
  new_hash
end

def xor_select(array, prc_1, prc_2) 
  new_array = []
  array.each do |el|
    # Use and logic to know if each element in the array is passing both tests
    if prc_1.call(el) && prc_2.call(el)
      # and reject that element if so
      next
    # This logic works because it comes after the above if statement
    elsif prc_1.call(el) || prc_2.call(el)
      new_array << el
    end
  end
  new_array
end

def proc_count(value, array)
  count = 0
  # Same thing as the proc_one? above, execpt just return the count insead
  # of checking to see that count is equal to 1
  array.each { |prc| count += 1 if prc.call(value) }
  count
end