require "byebug"

def proper_factors(number)
  # Keep track of all positive numbers less than the argument that also divide the argument
  proper_factors = []
  (1...number).each do |x|
    proper_factors << x if number % x == 0
  end
  proper_factors
end

def aliquot_sum(number)
  # Sum all the numbers found above
  proper_factors(number).sum
end

def perfect_number?(number)
  # if the number itself is equal to the sum found above, return true
  number == aliquot_sum(number)
end

def ideal_numbers(n)
  # an perfect number must be greater than 1
  ideal_number = 2
  # keep track of the perfect numbers
  ideal_numbers = []

  while n > 0
    ideal = false 
    while !ideal
      if perfect_number?(ideal_number)
        ideal_numbers << ideal_number
        ideal = true
      end
      ideal_number += 1
    end
    n -= 1
  end

  ideal_numbers
end
