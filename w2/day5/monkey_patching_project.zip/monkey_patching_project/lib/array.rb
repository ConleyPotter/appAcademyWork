# Monkey-Patch Ruby's existing Array class to add your own custom methods
class Array
  def span
    if self.length > 0
      return self.max - self.min
    else
      return nil
    end
  end

  def average
    if self.length > 0 && self.all? { |el| el.integer? }
      return self.sum / (self.length * 1.0)
    else
      return nil
    end
  end

  def median
    if self.length > 0
      if self.length % 2 == 1
        return self.sort[self.length / 2]
      else
        return ((self.sort[self.length / 2] + self.sort[(self.length / 2) - 1]) / 2.0)
      end
    else
      return nil
    end
  end

  def counts
    count_hash = Hash.new { |hash, key| hash[key] = 0 }
    self.each { |el| count_hash[el] += 1 }
    count_hash
  end

  def my_count(val)
    return self.counts[val]
  end

  def my_index(val)
    if self.include?(val)
      self.each_with_index do |el, idx| 
        if el == val
          return idx
        end
      end
    else
      return nil
    end
  end

  def my_uniq
    new_array = []

    self.each do |el|
      if !new_array.include?(el)
        new_array << el
      end
    end

    new_array
  end

  def my_transpose
    vert_counter = 0
    transposed_array = Array.new(self[0].length) { Array.new(self[1].length) }

    while vert_counter < self[1].length 
      horiz_counter = 0

      while horiz_counter < self[0].length
        transposed_array[horiz_counter][vert_counter] = self[vert_counter][horiz_counter]
        horiz_counter += 1
      end

      vert_counter += 1
    end

    transposed_array
  end
end
