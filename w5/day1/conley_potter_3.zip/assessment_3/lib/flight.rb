class Flight

  attr_reader :passengers

  def initialize(flight_number, capacity)
    @flight_number = flight_number
    @capacity = capacity
    @passengers = []
  end

  def full?
    if @passengers.length >= @capacity
      return true
    end
    false
  end

  def board_passenger(new_passenger)
    if !self.full?
      if new_passenger.has_flight?(@flight_number)
        @passengers << new_passenger
      end
    end
  end

  def list_passengers
    passengers_array = []
    @passengers.each { |passenger| passengers_array << passenger.name }
    passengers_array
  end

  def [](idx_number)
    @passengers[idx_number]
  end

  def <<(new_passenger)
    self.board_passenger(new_passenger)
  end
end