# require_relative "piece"
# require 'singleton'
# require "byebug"
# debugger


